# About

This is a ScreenCloud plugin that can upload images to Zapier.

![ScreenCloud Installed](http://i.imgur.com/thAg857.png)

# Install

1. Download and install ScreenCloud from http://screencloud.net/
2. Run this on a command line:

`git clone https://github.com/mikeknoop/zapier-screencloud.git ~/.local/share/data/screencloud/ScreenCloud/plugins/zapier`

## Ubuntu 13.04
`~/.local/share/data/screencloud/ScreenCloud/plugins/`

Then simply restart ScreenCloud. You'll need to edit the settings and specify the URL to upload to.
